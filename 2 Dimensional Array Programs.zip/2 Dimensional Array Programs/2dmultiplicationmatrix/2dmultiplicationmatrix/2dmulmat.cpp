#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	int **a,**b,**m,i,j,x,y,p,q,k,n,sum=0;
	printf("enter the size of array");
	scanf("%d",&n);
	a=(int**)malloc(n*sizeof(int*));
	b=(int**)malloc(n*sizeof(int*));
	m=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	{
		*(a+i)=(int*)malloc(n*sizeof(int));
	}
	for(i=0;i<n;i++)
	{
		*(b+i)=(int*)malloc(n*sizeof(int));
	}
	for(i=0;i<n;i++)
	{
		*(m+i)=(int*)malloc(n*sizeof(int));
	}
	printf("enter rows and column of matrix");
	scanf("%d%d",&x,&y);
	printf("enter element of 1st matrix");
	for(i=0;i<x;i++)
	{
		for(j=0;j<y;j++)
		{
			scanf("%d\n",*(a+i)+j);
		}
	}
	
	printf("enter rows and column of 2nd matrix");
	scanf("%d%d",&p,&q);
	printf("enter element of 2nd matrix");
	for(i=0;i<p;i++)
	{
		for(j=0;j<q;j++)
		{
			scanf("%d\n",*(b+i)+j);
		}
	}
	for(i=0;i<x;i++)
	{
		for(j=0;j<q;j++)
		{
			for(k=0;k<p;k++)
			{
				sum=sum+[*(*(a+i)+k)]*[*(*(b+k)+j)];
			}

			*(*(m+i)+j)=sum;
			sum=0;
		}
	}
	printf("product matrix is=");
	for(i=0;i<p;i++)
	{
		for(j=0;j<q;j++)
		{
			printf("%d\t",*(*(m+i)+j));
		}
		printf("/n");
	}
	getch();
}