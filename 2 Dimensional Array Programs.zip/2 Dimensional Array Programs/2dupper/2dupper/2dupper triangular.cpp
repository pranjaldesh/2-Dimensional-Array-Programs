//2d upper triangular matrix
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	int row,col;
	int **p,flag=0,i,j,n;
	printf("enter the size of array");
	scanf("%d",&n);
	p=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	{
		*(p+i)=(int*)malloc(n*sizeof(int));
	}
	printf("enter rows and column");
	scanf("%d%d",&row,&col);
	printf("enter array element");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d\n",*(p+i)+j);
		}
	}
	
	printf("array element are\n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(p+i)+j));
		}

	printf("\n");
	}
	for(i=1;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			if(*(*(p+i)+j)!=0)
				flag++;
			break;
		}

	printf("\n");
	}
	if(flag==0)
	{
		printf("MATRIX IS UPPER TRIANGULAR MATRIX");
	}
	else
	{
		printf("MATRIX IS NOT UPPER TRIANGULAR MATRIX");
	}
	getch();
}