//2d unit matrix 
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	int row,col,i,j,flag=1,n;
	int **p=NULL;
	printf("enter the size of array");
	scanf("%d",&n);
	p=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	{
		*(p+i)=(int*)malloc(n*sizeof(int));
	}
	printf("enter rows and column");
	scanf("%d%d",&row,&col);
	printf("enter array element");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d\n",*(p+i)+j);
		}
	}
	
	printf("array element are\n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(p+i)+j));
		}

	printf("\n");
	}
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			if(i==j&&*(*(p+i)+j)!=1)
			{
				flag=0;
				break;
			}
			else if(i!=j&&*(*(p+i)+j)!=0)
			{
				flag=0;
				break;
			}
		}
	}
	if(flag==1)
	{
		printf("MATRIX IS UNIT MATRIX");
	}
	else
	{
		printf("MATRIX IS NOT UNIT MATRIX");
	}
	getch();
}