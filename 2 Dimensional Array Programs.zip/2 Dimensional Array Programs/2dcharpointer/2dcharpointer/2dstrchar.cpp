//character pointer in static memory allocation
#include<stdio.h>
#include<conio.h>
int main()
{
	char str[100];
	char *ptr;
	printf("enter a string\n");
	fgets(str,sizeof(str),stdin);
	printf("string is=%s\n",str);
	ptr=str;
	while(*ptr!='\0')
	{
		printf("string using character pointer=%c",*ptr++);
	}
	getch();
}
