#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
int binarysearch();
void main()
{

	int *p=NULL,i,n,ele;
	printf("enter the size of array");
	scanf("%d",&n);
	p=(int*)malloc(n*sizeof(int));
	printf("enter the array element");
	for(i=0;i<n;i++)
	{
		scanf("%d\n",p+i);
	}
	printf("array elements are");
	for(i=0;i<n;i++)
	{
	printf("%d\t",*(p+i));
	}
	printf("enter elment to be searched");
	scanf("%d",&ele);
	binarysearch();
	getch();
}
	int binarysearch()
	{
		int p,ele,i;
		int start=0;
		int end=0;
		int mid=(start+end)/2;
			while(start<end&&*(p+mid)=ele)
			{
				if(ele<*(p+mid))
				end=mid-1;
				else
					start=mid+1;
				mid=start+end/2;
			}
			if(*(p+mid)==ele)
			printf("element is found at%d",mid+1);
			else
				printf("element not exit");
		
	}
