//2d matrix diagonal matrix
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	int row,col;
	int **p,i,j,n;
	printf("enter the size of array");
	scanf("%d",&n);
	p=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	{
		*(p+i)=(int*)malloc(n*sizeof(int));
	}

	printf("enter rows and column");
	scanf("%d%d",&row,&col);
	printf("enter array element");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d\n",*(p+i)+j);
		}
	}
	
	printf("array element are\n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(p+i)+j));
		}

	printf("\n");
	}
	printf("diagonal element are=\n");
	if(row==col)
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			if(i==j)
			{
				printf("%d\t",*(*(p+i)+j));
			}
			else 
			{
				printf("\t");
			}
		}
		printf("\n");
	}
	else
	{
		printf("It is not square matrix");
	}
	getch();
}