//2d transpose matrix 
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void main()
{
	int row,col;
	int **p,**t,i,j,n;
	printf("enter the size of array");
	scanf("%d",&n);
	p=(int**)malloc(n*sizeof(int*));
	t=(int**)malloc(n*sizeof(int*));
	for(i=0;i<n;i++)
	{
		*(p+i)=(int*)malloc(n*sizeof(int));
	}
	for(i=0;i<n;i++)
	{
		*(t+i)=(int*)malloc(n*sizeof(int));
	}
	printf("enter rows and column");
	scanf("%d%d",&row,&col);
	printf("enter array element");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			scanf("%d\n",*(p+i)+j);
		}
	}
	
	printf("array element are\n");
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(p+i)+j));
		}

	printf("\n");
	}
	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			*(*(t+j)+i)=*(*(p+i)+j);
		}
	}
	printf("transpose of the matrix is=");

	for(i=0;i<row;i++)
	{
		for(j=0;j<col;j++)
		{
			printf("%d\t",*(*(t+i)+j));
		}
		printf("\n");
	}
	getch();
}